<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/io.css">
        <meta name="description" content="">
        <meta name="author" content="">

        <title> Fashion Store View-feedback page</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="stylesheet" href="css/io2.css">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link rel="stylesheet" href="css/animista.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;400;700;900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/io3.css">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link rel="stylesheet" href="css/slick.css"/>

        <link href="css/tooplate-little-fashion.css" rel="stylesheet">

    </head>
    
    <body >

       
    
        <main>

            <nav class="navbar navbar-expand-lg">
                <div class="container">
                   

                    <p class="navbar-brand" href="">
                        <strong><span>Fashion</span> Store</strong>
                    </p>

                    

                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mx-auto">
                            <li class="nav-item">
                                <a class="nav-link " href="home.php">Home</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="insert.php">Insert</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="view-products.php">Product</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link " href="view-order.php">Order</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link active" href="view-feedbck.php">Feedback</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Log out</a>
                            </li>
                        </ul>

                       
                    </div>
                </div>
            </nav>
<br><br><br><br>
<br>
<h2 class="text-flicker-in-glow">View-feedback</h2>
<div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Message</th>
        
         
        </tr>
        <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from content ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['con_id'];					
									$prodno=$row['name'];
									$name=$row['email'];
									$phone=$row['phone'];
									$address=$row['mesg'];
									
						?>
      </thead>
      <tbody>
        <tr>
          <td><?php echo $id; ?></td>
          <td><?php echo $name; ?></td>
          <td><?php echo $email; ?></td>
          <td><?php echo $phone; ?></td>
          <td><?php echo $mesg; ?> </td>
          
        </tr>
      </tbody>
      <?php				  
		}	
					?>
    </table>
  </div>


        <br><br><br><br>

     

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/Headroom.js"></script>
        <script src="js/jQuery.headroom.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/custom.js"></script>
        <?php }  ?>
    </body>
    </html>